#!/usr/bin/env python3
"""
Генератор монохромной иконки для уведомлений Android

Из цветной PNG создает белую силуэтную версию для использования в уведомлениях.
Android требует монохромные иконки для уведомлений (обычно белые на прозрачном фоне).
"""

import sys
import os
from pathlib import Path
from PIL import Image

# Размеры для drawable-*dpi
NOTIFICATION_SIZES = {
    'mdpi': 24,
    'hdpi': 36,
    'xhdpi': 48,
    'xxhdpi': 72,
    'xxxhdpi': 96
}


def create_white_silhouette(image, size):
    """
    Создает белый силуэт из изображения

    Args:
        image: PIL Image объект
        size: размер выходной иконки

    Returns:
        PIL Image - белый силуэт на прозрачном фоне
    """
    # Конвертируем в RGBA если нужно
    if image.mode != 'RGBA':
        image = image.convert('RGBA')

    # Убираем прозрачные поля перед масштабированием,
    # чтобы иконка в уведомлении не выглядела слишком маленькой.
    alpha_bbox = image.getchannel('A').getbbox()
    if alpha_bbox:
        image = image.crop(alpha_bbox)

    # Изменяем размер
    resized = image.resize((size, size), Image.Resampling.LANCZOS)

    white_silhouette = Image.new('RGBA', (size, size), (0, 0, 0, 0))

    # Получаем данные пикселей
    pixels = resized.load()
    white_pixels = white_silhouette.load()

    # Превращаем любой видимый контур в белый силуэт.
    # Это лучше работает для проектных PNG-иконок на прозрачном фоне,
    # независимо от их исходного цвета.
    for y in range(size):
        for x in range(size):
            r, g, b, a = pixels[x, y]
            if a > 0:
                white_pixels[x, y] = (255, 255, 255, a)

    return white_silhouette


def generate_notification_icons(source_path, output_base_dir):
    """
    Генерирует монохромные иконки для уведомлений

    Args:
        source_path: путь к исходному PNG файлу
        output_base_dir: базовая директория для сохранения (app/src/main/res)
    """
    print(f"Загружаем исходную иконку: {source_path}")

    # Загружаем исходное изображение
    source_image = Image.open(source_path)

    # Проверяем, что это RGBA
    if source_image.mode != 'RGBA':
        print(f"Конвертируем из {source_image.mode} в RGBA")
        source_image = source_image.convert('RGBA')

    print(f"Исходный размер: {source_image.size}")
    print()
    print("Создаем монохромные версии для уведомлений...")
    print()

    # Генерируем иконки для каждого DPI
    for dpi, size in NOTIFICATION_SIZES.items():
        drawable_dir = os.path.join(output_base_dir, f'drawable-{dpi}')

        # Создаем директорию если её нет
        os.makedirs(drawable_dir, exist_ok=True)

        # Генерируем белую монохромную иконку
        notification_icon = create_white_silhouette(source_image, size)
        icon_path = os.path.join(drawable_dir, 'ic_notification.png')
        notification_icon.save(icon_path, 'PNG', optimize=True)
        print(f"✓ Создано: {icon_path} ({size}x{size})")

    print()
    print("Готово! Монохромные иконки для уведомлений созданы.")
    print()
    print("Следующие шаги:")
    print("1. Проверьте иконки в app/src/main/res/drawable-*/")
    print("2. Удалите старую векторную иконку: app/src/main/res/drawable/ic_notification.xml")
    print("3. Пересоберите проект: ./gradlew assembleDebug")


def main():
    if len(sys.argv) < 2:
        print("Использование: python3 generate_notification_icon.py <source_image.png>")
        print("Пример: python3 scripts/generate_notification_icon.py icon/app-icon.png")
        sys.exit(1)

    # Определяем пути
    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    source_icon = Path(sys.argv[1])
    res_dir = project_root / "app" / "src" / "main" / "res"

    print("=" * 60)
    print("Генератор монохромных иконок для уведомлений Android")
    print("=" * 60)
    print()

    # Проверяем существование исходного файла
    if not source_icon.exists():
        print(f"Ошибка: исходный файл не найден: {source_icon}")
        sys.exit(1)

    # Проверяем существование директории ресурсов
    if not res_dir.exists():
        print(f"Ошибка: директория ресурсов не найдена: {res_dir}")
        sys.exit(1)

    # Генерируем иконки
    generate_notification_icons(str(source_icon), str(res_dir))


if __name__ == "__main__":
    main()
