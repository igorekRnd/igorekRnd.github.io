#!/usr/bin/env python3
"""
Подготовка скриншотов для RuStore.

Скрипт масштабирует изображения с сохранением пропорций и добавляет фоновые поля
до целевого размера (по умолчанию 900x1600).

Цвет фона можно:
- задать вручную: --bg-color "#RRGGBB" или "R,G,B"
- определить автоматически один раз для всего набора: --auto-color
"""

from __future__ import annotations

import argparse
import statistics
from pathlib import Path
from typing import Iterable, Sequence

from PIL import Image, ImageOps

SUPPORTED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Подготовка скриншотов для RuStore (padding до нужного разрешения)."
    )
    parser.add_argument("input_dir", type=Path, help="Папка с исходными скриншотами")
    parser.add_argument("output_dir", type=Path, help="Папка для обработанных скриншотов")
    parser.add_argument("--width", type=int, default=900, help="Целевая ширина (по умолчанию 900)")
    parser.add_argument("--height", type=int, default=1600, help="Целевая высота (по умолчанию 1600)")

    bg_group = parser.add_mutually_exclusive_group()
    bg_group.add_argument(
        "--bg-color",
        type=str,
        help="Цвет фона: #RRGGBB или R,G,B",
    )
    bg_group.add_argument(
        "--auto-color",
        action="store_true",
        help="Автоматически определить один цвет фона для всего набора (по краям изображений)",
    )

    parser.add_argument(
        "--quality",
        type=int,
        default=95,
        help="Качество для JPEG/WebP (по умолчанию 95)",
    )
    return parser.parse_args()


def parse_color(value: str) -> tuple[int, int, int]:
    value = value.strip()
    if value.startswith("#"):
        hex_value = value[1:]
        if len(hex_value) != 6:
            raise ValueError("HEX-цвет должен быть формата #RRGGBB")
        return tuple(int(hex_value[i : i + 2], 16) for i in (0, 2, 4))

    parts = [part.strip() for part in value.split(",")]
    if len(parts) != 3:
        raise ValueError("Цвет должен быть в формате #RRGGBB или R,G,B")

    channels = tuple(int(part) for part in parts)
    if any(channel < 0 or channel > 255 for channel in channels):
        raise ValueError("Каналы RGB должны быть в диапазоне 0..255")
    return channels


def list_images(input_dir: Path) -> list[Path]:
    files = [
        path
        for path in sorted(input_dir.iterdir())
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS
    ]
    return files


def edge_samples(rgb_image: Image.Image) -> Iterable[tuple[int, int, int]]:
    width, height = rgb_image.size
    px = rgb_image.load()
    border = max(1, min(6, width // 50))
    step = max(1, height // 200)

    for y in range(0, height, step):
        for x in range(border):
            yield px[x, y]
            yield px[width - 1 - x, y]


def median_color(samples: Sequence[tuple[int, int, int]]) -> tuple[int, int, int]:
    if not samples:
        return 240, 240, 240
    r = int(statistics.median([s[0] for s in samples]))
    g = int(statistics.median([s[1] for s in samples]))
    b = int(statistics.median([s[2] for s in samples]))
    return r, g, b


def detect_global_bg_color(images: Sequence[Path]) -> tuple[int, int, int]:
    samples: list[tuple[int, int, int]] = []
    for path in images:
        with Image.open(path) as img:
            rgb = ImageOps.exif_transpose(img).convert("RGB")
            samples.extend(edge_samples(rgb))
    return median_color(samples)


def render_with_padding(
    source: Path,
    destination: Path,
    target_width: int,
    target_height: int,
    bg_color: tuple[int, int, int],
    quality: int,
) -> None:
    with Image.open(source) as img:
        img = ImageOps.exif_transpose(img)

        if img.mode in ("RGBA", "LA"):
            base = Image.new("RGBA", img.size, bg_color + (255,))
            img = Image.alpha_composite(base, img.convert("RGBA")).convert("RGB")
        else:
            img = img.convert("RGB")

        src_w, src_h = img.size
        scale = min(target_width / src_w, target_height / src_h)
        new_w = max(1, int(round(src_w * scale)))
        new_h = max(1, int(round(src_h * scale)))

        resized = img.resize((new_w, new_h), Image.Resampling.LANCZOS)

        canvas = Image.new("RGB", (target_width, target_height), bg_color)
        x = (target_width - new_w) // 2
        y = (target_height - new_h) // 2
        canvas.paste(resized, (x, y))

        destination.parent.mkdir(parents=True, exist_ok=True)

        suffix = destination.suffix.lower()
        if suffix in {".jpg", ".jpeg"}:
            canvas.save(destination, format="JPEG", quality=quality, optimize=True)
        elif suffix == ".webp":
            canvas.save(destination, format="WEBP", quality=quality)
        else:
            canvas.save(destination, format="PNG", optimize=True)


def main() -> int:
    args = parse_args()

    input_dir: Path = args.input_dir
    output_dir: Path = args.output_dir

    if not input_dir.exists() or not input_dir.is_dir():
        print(f"Ошибка: входная папка не найдена: {input_dir}")
        return 1

    if args.width <= 0 or args.height <= 0:
        print("Ошибка: width и height должны быть положительными")
        return 1

    images = list_images(input_dir)
    if not images:
        print(f"Ошибка: в папке нет поддерживаемых изображений: {input_dir}")
        return 1

    if args.bg_color:
        try:
            bg_color = parse_color(args.bg_color)
        except ValueError as exc:
            print(f"Ошибка цвета фона: {exc}")
            return 1
        bg_source = "ручной"
    else:
        bg_color = detect_global_bg_color(images)
        bg_source = "авто"

    print("=" * 60)
    print("Подготовка скриншотов для RuStore")
    print("=" * 60)
    print(f"Вход:  {input_dir}")
    print(f"Выход: {output_dir}")
    print(f"Размер: {args.width}x{args.height}")
    print(f"Фон: {bg_color} ({bg_source})")
    print(f"Файлов: {len(images)}")
    print()

    for source in images:
        destination = output_dir / source.name
        render_with_padding(
            source=source,
            destination=destination,
            target_width=args.width,
            target_height=args.height,
            bg_color=bg_color,
            quality=max(1, min(100, args.quality)),
        )
        print(f"✓ {source.name} -> {destination.name}")

    print()
    print("Готово.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
