#!/usr/bin/env python3
"""
Генератор адаптивных иконок для Android (API 26+)

Создает foreground слой для adaptive icon из исходного изображения.
"""

import sys
import os
import re
import argparse
from pathlib import Path
from PIL import Image

# Размеры для mipmap-*dpi (foreground должен быть 108x108dp с safe zone)
FOREGROUND_SIZES = {
    'mdpi': 108,      # 1x
    'hdpi': 162,      # 1.5x
    'xhdpi': 216,     # 2x
    'xxhdpi': 324,    # 3x
    'xxxhdpi': 432    # 4x
}


def create_foreground(image, size):
    """
    Создает foreground слой для adaptive icon

    Адаптивные иконки имеют размер 108x108dp, но видимая область (safe zone)
    составляет 72x72dp в центре. Поэтому нужно масштабировать иконку и
    разместить ее в центре с отступами.

    Args:
        image: PIL Image объект
        size: размер выходной иконки (108dp в соответствующем DPI)

    Returns:
        PIL Image - foreground слой на прозрачном фоне
    """
    # Конвертируем в RGBA если нужно
    if image.mode != 'RGBA':
        image = image.convert('RGBA')

    # Safe zone - 72/108 = 2/3 от полного размера
    # Но мы хотим чтобы иконка заполняла safe zone, поэтому масштабируем до 72dp
    safe_zone_size = int(size * 2 / 3)  # 72dp в текущем DPI

    # Масштабируем исходную иконку до размера safe zone
    scaled = image.resize((safe_zone_size, safe_zone_size), Image.Resampling.LANCZOS)

    # Создаем прозрачный холст 108x108
    foreground = Image.new('RGBA', (size, size), (0, 0, 0, 0))

    # Вычисляем отступ для центрирования (18dp с каждой стороны)
    offset = (size - safe_zone_size) // 2

    # Вставляем масштабированную иконку в центр
    foreground.paste(scaled, (offset, offset), scaled)

    return foreground


def create_adaptive_icon_xml():
    """
    Создает XML-файл для adaptive icon
    """
    return '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>'''


def get_dominant_dark_color(image):
    """
    Определяет доминирующий темный цвет из изображения для фона

    Args:
        image: PIL Image объект

    Returns:
        str: цвет в формате #RRGGBB
    """
    # Уменьшаем изображение для быстрой обработки
    small = image.resize((50, 50), Image.Resampling.LANCZOS)
    pixels = small.getdata()

    # Собираем темные пиксели (яркость < 100)
    dark_pixels = []
    for pixel in pixels:
        if len(pixel) >= 3:  # RGB или RGBA
            r, g, b = pixel[:3]
            brightness = (r + g + b) / 3
            if brightness < 100:
                dark_pixels.append((r, g, b))

    if dark_pixels:
        # Находим средний цвет среди темных пикселей
        avg_r = sum(p[0] for p in dark_pixels) // len(dark_pixels)
        avg_g = sum(p[1] for p in dark_pixels) // len(dark_pixels)
        avg_b = sum(p[2] for p in dark_pixels) // len(dark_pixels)
        return f"#{avg_r:02X}{avg_g:02X}{avg_b:02X}"

    # Если темных пикселей нет, возвращаем темно-серый
    return "#1A1A2E"


def normalize_background(value):
    """
    Нормализует значение фона, переданное через --background.

    Принимает 'transparent' либо hex-цвет (#RGB, #ARGB, #RRGGBB, #AARRGGBB;
    ведущий '#' необязателен). Возвращает строку вида '#RRGGBB' / '#AARRGGBB'
    / '#00000000', либо None, если значение не задано (тогда цвет подбирается
    автоматически из картинки).

    Args:
        value: строка из аргумента --background или None

    Returns:
        str | None: нормализованный цвет или None
    """
    if value is None:
        return None
    v = value.strip()
    if v.lower() == 'transparent':
        return '#00000000'
    m = re.fullmatch(r'#?([0-9A-Fa-f]{3,4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})', v)
    if not m:
        raise ValueError(
            f"некорректный цвет фона: '{value}'. "
            f"Ожидается 'transparent' или hex (#RGB, #ARGB, #RRGGBB, #AARRGGBB)."
        )
    return '#' + m.group(1).upper()


def generate_adaptive_icons(source_path, output_base_dir, background=None):
    """
    Генерирует foreground слои и XML-файлы для адаптивных иконок

    Args:
        source_path: путь к исходному PNG файлу
        output_base_dir: базовая директория для сохранения (app/src/main/res)
    """
    print(f"Загружаем исходную иконку: {source_path}")

    # Загружаем исходное изображение
    source_image = Image.open(source_path)

    # Проверяем, что это RGBA
    if source_image.mode != 'RGBA':
        print(f"Конвертируем из {source_image.mode} в RGBA")
        source_image = source_image.convert('RGBA')

    print(f"Исходный размер: {source_image.size}")
    print()

    # Определяем цвет фона
    if background is not None:
        bg_color = background
        print(f"Цвет фона задан вручную: {bg_color}")
    else:
        bg_color = get_dominant_dark_color(source_image)
        print(f"Определен цвет фона (автоподбор): {bg_color}")
    print()

    print("Создаем foreground слои для адаптивных иконок...")
    print()

    # Генерируем foreground для каждого DPI
    for dpi, size in FOREGROUND_SIZES.items():
        mipmap_dir = os.path.join(output_base_dir, f'mipmap-{dpi}')

        # Создаем директорию если её нет
        os.makedirs(mipmap_dir, exist_ok=True)

        # Генерируем foreground
        foreground = create_foreground(source_image, size)
        foreground_path = os.path.join(mipmap_dir, 'ic_launcher_foreground.png')
        foreground.save(foreground_path, 'PNG', optimize=True)
        print(f"✓ Создано: {foreground_path} ({size}x{size})")

    print()
    print("Создаем XML-файлы для адаптивных иконок...")
    print()

    # Создаем директорию mipmap-anydpi-v26
    anydpi_dir = os.path.join(output_base_dir, 'mipmap-anydpi-v26')
    os.makedirs(anydpi_dir, exist_ok=True)

    # Создаем ic_launcher.xml
    launcher_xml_path = os.path.join(anydpi_dir, 'ic_launcher.xml')
    with open(launcher_xml_path, 'w', encoding='utf-8') as f:
        f.write(create_adaptive_icon_xml())
    print(f"✓ Создано: {launcher_xml_path}")

    # Создаем ic_launcher_round.xml
    launcher_round_xml_path = os.path.join(anydpi_dir, 'ic_launcher_round.xml')
    with open(launcher_round_xml_path, 'w', encoding='utf-8') as f:
        f.write(create_adaptive_icon_xml())
    print(f"✓ Создано: {launcher_round_xml_path}")

    print()
    print("Обновляем colors.xml...")
    print()

    # Обновляем colors.xml
    colors_path = os.path.join(output_base_dir, 'values', 'colors.xml')
    if os.path.exists(colors_path):
        with open(colors_path, 'r', encoding='utf-8') as f:
            colors_content = f.read()

        # Проверяем, есть ли уже ic_launcher_background
        if 'ic_launcher_background' in colors_content:
            # Заменяем существующий цвет (любой hex, в т.ч. 8-значный с альфой)
            colors_content = re.sub(
                r'<color name="ic_launcher_background">#[0-9A-Fa-f]{3,8}</color>',
                f'<color name="ic_launcher_background">{bg_color}</color>',
                colors_content
            )
            print(f"✓ Обновлен цвет ic_launcher_background: {bg_color}")
        else:
            # Добавляем новый цвет перед закрывающим тегом </resources>
            colors_content = colors_content.replace(
                '</resources>',
                f'    <color name="ic_launcher_background">{bg_color}</color>\n</resources>'
            )
            print(f"✓ Добавлен цвет ic_launcher_background: {bg_color}")

        with open(colors_path, 'w', encoding='utf-8') as f:
            f.write(colors_content)
        print(f"✓ Обновлено: {colors_path}")
    else:
        print(f"⚠ Файл colors.xml не найден: {colors_path}")

    print()
    print("Готово! Адаптивные иконки полностью настроены.")
    print()
    print("Созданные файлы:")
    print("  ✓ mipmap-anydpi-v26/ic_launcher.xml")
    print("  ✓ mipmap-anydpi-v26/ic_launcher_round.xml")
    print("  ✓ mipmap-*/ic_launcher_foreground.png")
    print("  ✓ values/colors.xml (ic_launcher_background)")


def main():
    parser = argparse.ArgumentParser(
        description="Генератор адаптивных иконок для Android (API 26+)",
        epilog="Примеры:\n"
               "  python3 generate_adaptive_icons.py icon.png\n"
               "  python3 generate_adaptive_icons.py icon.png --background transparent\n"
               "  python3 generate_adaptive_icons.py icon.png --background '#1A1A2E'",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("source_image", help="Путь к исходному PNG")
    parser.add_argument(
        "-b", "--background",
        help="Цвет фона адаптивной иконки: 'transparent' или hex "
             "(#RGB, #ARGB, #RRGGBB, #AARRGGBB). По умолчанию — автоподбор "
             "доминирующего тёмного цвета из картинки."
    )
    args = parser.parse_args()

    # Определяем пути
    source_path = Path(args.source_image)
    try:
        background = normalize_background(args.background)
    except ValueError as e:
        print(f"Ошибка: {e}")
        sys.exit(1)

    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    res_dir = project_root / "app" / "src" / "main" / "res"

    print("=" * 60)
    print("Генератор адаптивных иконок для Android (API 26+)")
    print("=" * 60)
    print()

    # Проверяем существование исходного файла
    if not source_path.exists():
        print(f"Ошибка: исходный файл не найден: {source_path}")
        sys.exit(1)

    # Проверяем существование директории ресурсов
    if not res_dir.exists():
        print(f"Ошибка: директория ресурсов не найдена: {res_dir}")
        sys.exit(1)

    # Генерируем иконки
    generate_adaptive_icons(str(source_path), str(res_dir), background)


if __name__ == "__main__":
    main()
