#!/usr/bin/env bash
# Готовит скриншоты для карточки RuStore: масштабирует до 900x1600 и добавляет поля.
# Кладите снимки с телефона в raw/, забирайте готовые из rustore/.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"

# Тёмно-синий фон полей — цвет иконки приложения (#023691)
python3 "$ROOT_DIR/scripts/prepare_rustore_screenshots.py" \
  "$ROOT_DIR/publication/screenshots/raw" \
  "$ROOT_DIR/publication/screenshots/rustore" \
  --bg-color "2,54,145"
