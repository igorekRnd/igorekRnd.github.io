#!/usr/bin/env bash
# Сборка форка NotiFilter: собрать, подписать ключом из keystore.properties, поставить на телефон.
# Лежит в репозитории: по GPLv3 скрипт сборки входит в состав исходников, которые мы раздаём.
#
#   ./build.sh              собрать release, подписать, установить
#   ./build.sh build        только собрать и подписать
#   ./build.sh install      установить уже собранный APK
#   ./build.sh publication  собрать пакет для публикации: APK, архив исходников,
#                           changelog; архив заодно выкладывается на страницу приложения
#   ./build.sh debug        debug-сборка (ставится рядом с оригиналом, суффикс .debug)
#   ./build.sh export       напомнить, как сохранить фильтры перед заменой оригинала
#   ./build.sh uninstall    удалить приложение с телефона
#   ./build.sh test         прогнать юнит-тесты
#   ./build.sh lint         прогнать lint

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

SDK_DIR="${ANDROID_HOME:-$HOME/Android/Sdk}"
BUILD_TOOLS="$SDK_DIR/build-tools/36.0.0"
ZIPALIGN="$BUILD_TOOLS/zipalign"
APKSIGNER="$BUILD_TOOLS/apksigner"

UNSIGNED_APK="app/build/outputs/apk/release/app-release-unsigned.apk"
ALIGNED_APK="app/build/outputs/apk/release/app-release-aligned.apk"
SIGNED_APK="app/build/outputs/apk/release/NotiFilter-release.apk"
DEBUG_APK="app/build/outputs/apk/debug/app-debug.apk"
PUBLICATION_DIR="build/publication"
# Страница приложения: туда же выкладывается архив исходников
SITE_DIR="$HOME/projects/igorekRnd.github.io/notification-filter"

# Профиль-клон 900 на Moto дублирует установки, поэтому ставим только в основной профиль.
# Понижение versionCode система для release-сборки не разрешает даже с -d (это доступно
# только debuggable-приложениям), поэтому после смены нумерации нужен adb uninstall
ADB_INSTALL=(adb install --user 0 -r)

log() { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
die() { printf '\n\033[1;31mОшибка: %s\033[0m\n' "$1" >&2; exit 1; }

check_device() {
    adb start-server >/dev/null 2>&1 || true
    local devices
    devices="$(adb devices | awk 'NR>1 && $2=="device" {print $1}')"
    [ -n "$devices" ] || die "телефон не подключён (проверьте adb devices и отладку по USB)"
    log "устройство: $devices"
}

read_keystore() {
    local file="$PROJECT_DIR/keystore.properties"
    if [ ! -f "$file" ]; then
        die "нет keystore.properties. Скопируйте его из другого проекта:
    cp ~/AndroidStudioProjects/MyTasks/keystore.properties '$PROJECT_DIR/'
Формат: storeFile, storePassword, keyAlias, keyPassword"
    fi

    # Значения читаются в переменные окружения, чтобы пароли не попадали в список процессов
    KS_STORE_FILE="$(grep -E '^storeFile=' "$file" | cut -d= -f2-)"
    export KS_STORE_PASS="$(grep -E '^storePassword=' "$file" | cut -d= -f2-)"
    export KS_KEY_PASS="$(grep -E '^keyPassword=' "$file" | cut -d= -f2-)"
    KS_KEY_ALIAS="$(grep -E '^keyAlias=' "$file" | cut -d= -f2-)"

    [ -f "$KS_STORE_FILE" ] || die "ключ не найден: $KS_STORE_FILE"
}

do_build() {
    log "сборка release"
    ./gradlew --console=plain :app:assembleRelease

    [ -f "$UNSIGNED_APK" ] || die "APK не собрался: $UNSIGNED_APK"

    read_keystore

    log "выравнивание"
    [ -x "$ZIPALIGN" ] || die "нет zipalign: $ZIPALIGN"
    rm -f "$ALIGNED_APK"
    "$ZIPALIGN" -p 4 "$UNSIGNED_APK" "$ALIGNED_APK"

    log "подпись ключом $KS_KEY_ALIAS"
    [ -x "$APKSIGNER" ] || die "нет apksigner: $APKSIGNER"
    "$APKSIGNER" sign \
        --ks "$KS_STORE_FILE" \
        --ks-pass "env:KS_STORE_PASS" \
        --ks-key-alias "$KS_KEY_ALIAS" \
        --key-pass "env:KS_KEY_PASS" \
        --out "$SIGNED_APK" \
        "$ALIGNED_APK"
    rm -f "$ALIGNED_APK"

    "$APKSIGNER" verify --print-certs "$SIGNED_APK" | head -3

    log "готово: $SIGNED_APK ($(du -h "$SIGNED_APK" | cut -f1))"
}

do_install() {
    [ -f "$SIGNED_APK" ] || die "нет подписанного APK, сначала ./build.sh build"
    check_device

    log "установка"
    if ! "${ADB_INSTALL[@]}" "$SIGNED_APK"; then
        cat <<'EOF'

Установка не прошла. Пакет форка — ru.bia.notifilter, он ставится рядом
с оригинальным co.adityarajput.notifilter из F-Droid и не конфликтует с ним.
Если ошибка про подпись — на телефоне осталась прежняя сборка форка,
подписанная другим ключом: adb uninstall ru.bia.notifilter

Перенос фильтров между сборками (данные не наследуются, пакет другой):
  1. В прежней сборке: Настройки → Экспорт фильтров, сохранить JSON.
  2. ./build.sh install
  3. В новой: Настройки → Импорт фильтров, выбрать сохранённый JSON.
  4. Заново выдать доступ к уведомлениям.

История уведомлений и статистика срабатываний при этом не переносятся —
экспорт содержит только сами фильтры.
EOF
        exit 1
    fi

    log "установлено. Не забудьте выдать доступ к уведомлениям"
}

read_version() {
    local version
    version="$(sed -n 's/^[[:space:]]*versionName[[:space:]]*=[[:space:]]*"\(.*\)".*/\1/p' \
        app/build.gradle.kts | head -1)"
    [ -n "$version" ] || die "не удалось прочитать versionName из app/build.gradle.kts"
    printf '%s' "$version"
}

# Архив исходников: $1 — git-ref (HEAD или тег), $2 — каталог назначения.
# Отдаётся по требованию GPLv3 §6 и кладётся рядом с APK при публикации.
# Внутрь попадает только то, что в git: keystore.properties и CLAUDE.md в .gitignore,
# метаданные F-Droid автора, CI и конфиги IDE отсечены через .gitattributes.
build_sources_archive() {
    local ref="$1" dir="$2" version archive
    version="$(read_version)"
    # Для тега вида v1.0.0 версию берём из самого тега: build.gradle.kts мог уже уехать вперёд
    case "$ref" in v[0-9]*) version="${ref#v}" ;; esac

    git rev-parse --verify --quiet "$ref" >/dev/null || die "нет такого git-ref: $ref"

    mkdir -p "$dir"
    archive="$dir/notifilter-$version-src.tar.gz"
    git archive --format=tar.gz --prefix="notifilter-$version/" -o "$archive" "$ref"

    SOURCES_ARCHIVE="$archive"
}

# Раскладывает архив исходников на страницу приложения: по GPLv3 §6d исходники должны
# быть доступны там же, откуда раздаётся приложение, поэтому архив каждой выпущенной
# версии выкладывается на сайт рядом с карточкой в магазине.
publish_sources_to_site() {
    local archive="$1" dir="$SITE_DIR/sources" file

    if [ ! -d "$SITE_DIR" ]; then
        log "каталог страницы не найден: $SITE_DIR"
        printf 'Архив на сайт не скопирован — положите его туда вручную.\n'
        return 0
    fi

    mkdir -p "$dir"
    cp "$archive" "$dir/"

    # GitHub Pages не показывает список файлов в каталоге, поэтому индекс собираем сами
    {
        cat <<'HEAD'
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Исходный код — Фильтр уведомлений</title>
  <style>
    body {
      margin: 0;
      font-family: Verdana, Geneva, sans-serif;
      color: #16243d;
      background: linear-gradient(140deg, #e8f0fd 0%, #dde7fb 52%, #eff4fe 100%);
    }
    main { max-width: 920px; margin: 0 auto; padding: 30px 20px 64px; }
    a { color: #023691; }
    section {
      padding: 24px;
      border: 1px solid #c2d4f0;
      border-radius: 24px;
      background: rgba(246, 249, 255, 0.96);
    }
    li { line-height: 1.9; }
  </style>
</head>
<body>
  <main>
    <a href="/notification-filter/">Назад к приложению</a>
    <h1>Исходный код</h1>
    <section>
      <p>
        Приложение «Фильтр уведомлений» распространяется по лицензии
        <a href="https://www.gnu.org/licenses/gpl-3.0.html">GNU GPL версии 3</a>.
        Ниже — архивы исходных текстов выпущенных версий. Каждый архив содержит всё,
        что нужно для самостоятельной сборки, включая скрипт <code>build.sh</code>.
      </p>
      <ul>
HEAD
        for file in $(ls -1 "$dir"/*.tar.gz 2>/dev/null | sort -Vr); do
            printf '        <li><a href="%s">%s</a> — %s</li>\n' \
                "$(basename "$file")" "$(basename "$file")" "$(du -h "$file" | cut -f1)"
        done
        cat <<'TAIL'
      </ul>
      <p>
        Это сборка приложения <a href="https://github.com/BURG3R5/NotiFilter">NotiFilter</a>
        (автор оригинала — Aditya Rajput, BURG3R5) с доработками.
      </p>
    </section>
  </main>
</body>
</html>
TAIL
    } > "$dir/index.html"

    log "архив выложен на страницу: $dir/$(basename "$archive")"
    printf 'Не забудьте закоммитить и запушить сайт — иначе ссылка не заработает.\n'
}

# Пакет для магазина: APK, исходники этой же версии и список изменений.
# Исходники обязательны — GPLv3 §6d требует давать к ним доступ тем же способом,
# каким раздаётся собранное приложение.
do_publication() {
    local version out
    version="$(read_version)"

    # Иначе выложенные исходники не будут соответствовать выложенному APK
    if [ -n "$(git status --porcelain)" ]; then
        die "рабочее дерево не чистое — сначала закоммитьте изменения:
$(git status --short)"
    fi

    do_build

    out="$PUBLICATION_DIR/$version"
    rm -rf "$out"
    mkdir -p "$out"

    cp "$SIGNED_APK" "$out/NotiFilter-$version.apk"

    log "архив исходников версии $version"
    build_sources_archive HEAD "$out"

    publish_sources_to_site "$SOURCES_ARCHIVE"

    cp license "$out/LICENSE"
    [ -f CHANGELOG.md ] && cp CHANGELOG.md "$out/"
    [ -f readme.md ] && cp readme.md "$out/"

    log "zip для загрузки"
    rm -f "$PUBLICATION_DIR/notifilter-$version-publication.zip"
    (cd "$PUBLICATION_DIR" && zip -qr "notifilter-$version-publication.zip" "$version")

    log "готово: $PUBLICATION_DIR/notifilter-$version-publication.zip"
    ls -1sh "$out"
    printf '\nОсталось вручную: закоммитить сайт, описание и скриншоты для магазина.\n'
}

do_debug() {
    log "сборка debug (встанет рядом с оригиналом как ru.bia.notifilter.debug)"
    ./gradlew --console=plain :app:assembleDebug
    check_device
    "${ADB_INSTALL[@]}" "$DEBUG_APK"
    log "установлено. Внимание: в debug действие BATCH считает минуты вместо часов,"
    printf '    а база заполняется демо-фильтрами при первом запуске.\n'
}

case "${1:-all}" in
    all)
        do_build
        do_install
        ;;
    build)
        do_build
        ;;
    install)
        do_install
        ;;
    publication)
        do_publication
        ;;
    debug)
        do_debug
        ;;
    export)
        cat <<'EOF'
Перед заменой оригинала сохраните фильтры:
  оригинальный NotiFilter → Настройки → Экспорт фильтров → сохранить JSON.
После установки форка: Настройки → Импорт фильтров → выбрать этот JSON.
Импорт заменяет все текущие фильтры. История и счётчики не переносятся.
EOF
        ;;
    uninstall)
        check_device
        log "удаление ru.bia.notifilter"
        adb uninstall ru.bia.notifilter
        ;;
    test)
        log "юнит-тесты"
        ./gradlew --console=plain :app:testDebugUnitTest :evaluator:test
        ;;
    lint)
        log "lint"
        ./gradlew --console=plain :app:lintRelease
        printf 'Отчёт: app/build/reports/lint-results-release.html\n'
        ;;
    *)
        die "неизвестная команда: $1 (см. комментарий в начале build.sh)"
        ;;
esac
