package co.adityarajput.notifilter.views.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.*
import androidx.compose.ui.text.style.TextDecoration
import co.adityarajput.notifilter.R
import co.adityarajput.notifilter.data.models.RegexTarget
import co.adityarajput.notifilter.utils.generateRegex
import co.adityarajput.notifilter.utils.getFirst
import co.adityarajput.notifilter.viewmodels.UpsertFilterViewModel

@Composable
fun SupportingText(viewModel: UpsertFilterViewModel, isPrimaryPattern: Boolean) {
    if (viewModel.state.values.notification == null) return

    if (viewModel.state.values.regexTarget == RegexTarget.EXPRESSION) return

    val title = viewModel.state.values.notification!!.title
    val content = viewModel.state.values.notification!!.content

    val sample = (title.getFirst(20) to content.getFirst(20)).let { (title, content) ->
        when (viewModel.state.values.regexTarget) {
            RegexTarget.TITLE -> title

            RegexTarget.CONTENT -> content

            RegexTarget.OR -> "$title' ${stringResource(R.string.or)} '$content"

            RegexTarget.AND if (isPrimaryPattern) -> title

            else -> content
        }
    }

    // INFO: A pattern built from the title alone matches every notification an app sends
    // with that title, so for the OR target the content is used and the target is narrowed
    // down to it. The title is only used when there is no content to match against.
    val (pattern, target) = when (viewModel.state.values.regexTarget) {
        RegexTarget.TITLE -> title.generateRegex() to RegexTarget.TITLE

        RegexTarget.CONTENT -> content.generateRegex() to RegexTarget.CONTENT

        RegexTarget.OR ->
            if (content.isNotBlank()) content.generateRegex() to RegexTarget.CONTENT
            else title.generateRegex() to RegexTarget.TITLE

        RegexTarget.AND if (isPrimaryPattern) -> title.generateRegex() to RegexTarget.AND

        else -> content.generateRegex() to RegexTarget.AND
    }

    Text(
        buildAnnotatedString {
            append(stringResource(R.string.pattern_supporting, sample))
            withLink(
                LinkAnnotation.Clickable(
                    "generate",
                    TextLinkStyles(
                        SpanStyle(
                            MaterialTheme.colorScheme.primary,
                            textDecoration = TextDecoration.Underline,
                        ),
                    ),
                ) {
                    viewModel.updateForm(
                        viewModel.state.page,
                        viewModel.state.values.run {
                            if (isPrimaryPattern)
                                copy(queryPattern = pattern, regexTarget = target)
                            else copy(secondaryQueryPattern = pattern)
                        },
                    )
                },
            ) {
                append(stringResource(R.string.generate))
            }
        },
    )
}
