package co.adityarajput.notifilter.views.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import co.adityarajput.notifilter.R
import co.adityarajput.notifilter.data.models.Notification

/**
 * Shows the notification a filter is being built from, in full: a label in the same style
 * as the advice above, and below it the value itself on a filled background. Only the value
 * is selectable, so a word or a sentence can be copied into a pattern instead of being
 * typed out, while the labels stay out of the selection.
 */
@Composable
fun NotificationPreview(notification: Notification?) {
    if (notification == null) return

    if (notification.title.isBlank() && notification.content.isBlank()) return

    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = dimensionResource(R.dimen.padding_medium)),
        Arrangement.spacedBy(dimensionResource(R.dimen.padding_medium)),
    ) {
        if (notification.title.isNotBlank())
            LabelledValue(R.string.notification_title, notification.title)

        if (notification.content.isNotBlank())
            LabelledValue(R.string.notification_content, notification.content)
    }
}

@Composable
private fun LabelledValue(label: Int, value: String) {
    Column(
        Modifier.fillMaxWidth(),
        Arrangement.spacedBy(dimensionResource(R.dimen.padding_small)),
    ) {
        Text(
            stringResource(label),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Normal,
        )
        // INFO: A read-only text field rather than a SelectionContainer: dragging a
        // selection handle out of a plain short Text collapses the selection, while a
        // text field keeps it and offers the usual copy toolbar
        TextField(
            value,
            {},
            Modifier.fillMaxWidth(),
            readOnly = true,
            textStyle = MaterialTheme.typography.bodyMedium,
        )
    }
}
