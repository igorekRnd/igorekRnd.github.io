package co.adityarajput.notifilter.views

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavOptions
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.toRoute
import co.adityarajput.notifilter.utils.Permission
import co.adityarajput.notifilter.utils.isGranted
import co.adityarajput.notifilter.views.screens.*
import kotlinx.serialization.Serializable

/**
 * Goes back one screen, but only when the current one is fully resumed and there is
 * something left underneath. Plain [NavHostController.popBackStack] pops once per tap,
 * so taps that land while a transition is still running pop more entries than intended
 * and leave the NavHost with nothing to draw — a blank screen over a live activity.
 */
private fun NavHostController.goBack() {
    if (currentBackStackEntry?.lifecycle?.currentState != Lifecycle.State.RESUMED) return
    if (previousBackStackEntry == null) return

    popBackStack()
}

@Composable
fun Navigator(controller: NavHostController) {
    val hasPermission = remember { controller.context.isGranted(Permission.NOTIFICATION_LISTENER) }

    NavHost(
        controller,
        when {
            hasPermission -> Routes.FILTERS.name
            else -> Routes.ONBOARDING.name
        },
    ) {
        composable(Routes.ONBOARDING.name) {
            OnboardingScreen {
                controller.navigate(
                    Routes.FILTERS.name,
                    NavOptions.Builder().setPopUpTo(Routes.ONBOARDING.name, true).build(),
                )
            }
        }
        composable(Routes.FILTERS.name) {
            FiltersScreen(
                { controller.navigate(UpsertFilterRoute(it)) },
                { controller.navigate(Routes.NOTIFICATIONS.name) },
                { controller.navigate(FilterHistoryRoute(it)) },
                { controller.navigate(Routes.SETTINGS.name) },
            )
        }
        composable<UpsertFilterRoute> {
            UpsertFilterScreen(
                it.toRoute<UpsertFilterRoute>().filterString,
                controller::goBack,
            )
        }
        composable(Routes.NOTIFICATIONS.name) { NotificationsScreen(controller::goBack) }
        composable<FilterHistoryRoute> {
            NotificationsScreen(
                controller::goBack,
                it.toRoute<FilterHistoryRoute>().filterId,
            )
        }
        composable(Routes.SETTINGS.name) {
            SettingsScreen(
                { controller.navigate(Routes.LICENSES.name) },
                { controller.navigate(Routes.ABOUT.name) },
                controller::goBack,
            )
        }
        composable(Routes.LICENSES.name) { LicensesScreen(controller::goBack) }
        composable(Routes.ABOUT.name) { AboutScreen(controller::goBack) }
    }
}

enum class Routes {
    ONBOARDING,
    FILTERS,
    NOTIFICATIONS,
    SETTINGS,
    LICENSES,
    ABOUT,
}

@Serializable
data class UpsertFilterRoute(val filterString: String = "null")

@Serializable
data class FilterHistoryRoute(val filterId: Int)
