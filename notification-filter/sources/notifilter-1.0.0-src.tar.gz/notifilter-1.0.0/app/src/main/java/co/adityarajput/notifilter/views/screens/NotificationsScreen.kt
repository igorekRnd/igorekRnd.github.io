package co.adityarajput.notifilter.views.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.lifecycle.viewmodel.compose.viewModel
import co.adityarajput.notifilter.R
import co.adityarajput.notifilter.data.Cache
import co.adityarajput.notifilter.utils.Logger
import co.adityarajput.notifilter.utils.getFirst
import co.adityarajput.notifilter.utils.toDelta
import co.adityarajput.notifilter.viewmodels.NotificationDialogState
import co.adityarajput.notifilter.viewmodels.NotificationsViewModel
import co.adityarajput.notifilter.viewmodels.Provider
import co.adityarajput.notifilter.views.components.AppBar
import co.adityarajput.notifilter.views.components.ManageHistoryDialog
import co.adityarajput.notifilter.views.components.Tile

@Composable
fun NotificationsScreen(
    goBack: () -> Unit,
    filterId: Int? = null,
    viewModel: NotificationsViewModel = viewModel(
        factory = if (filterId == null) Provider.Factory else Provider.createNVM(filterId),
    ),
) {
    val context = LocalContext.current
    val state = viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            AppBar(
                stringResource(
                    if (filterId == null) R.string.history else R.string.filter_history,
                ),
                true,
                goBack,
            ) {
                IconButton({ viewModel.dialogState = NotificationDialogState.CLEAR_HISTORY }) {
                    Icon(
                        painterResource(R.drawable.delete),
                        stringResource(R.string.clear_history),
                        tint = MaterialTheme.colorScheme.tertiary,
                    )
                }
            }
        },
    ) { paddingValues ->
        if (state.value.notifications == null || viewModel.allPackages.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        } else if (state.value.notifications!!.isEmpty()) {
            Box(
                Modifier.fillMaxSize(),
                Alignment.Center,
            ) {
                Text(
                    stringResource(
                        if (filterId == null) R.string.no_notifications
                        else R.string.no_notifications_for_filter,
                    ),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        } else {
            LazyColumn(
                Modifier
                    .padding(paddingValues)
                    .padding(dimensionResource(R.dimen.padding_small))
                    .fillMaxSize(),
            ) {
                items(state.value.notifications!!, { it.id }) {
                    val intents = Cache.intents[it.data.hashCode()]

                    Tile(
                        it.title,
                        it.content,
                        it.appNameFrom(viewModel.allPackages).getFirst(30),
                        it.timestamp.toDelta(),
                        null,
                        {
                            try {
                                if (intents?.main != null) intents.launchMain() else {
                                    context.startActivity(
                                        context.packageManager.getLaunchIntentForPackage(
                                            it.origin,
                                        ),
                                    )
                                }
                            } catch (e: Exception) {
                                Logger.e("NotificationsScreen", "Error clicking $it", e)
                            }
                        },
                        { viewModel.delete(it) },
                        {
                            intents?.actions?.forEach { (title, intent) ->
                                Text(
                                    title,
                                    Modifier
                                        .padding(horizontal = dimensionResource(R.dimen.padding_small))
                                        .padding(top = dimensionResource(R.dimen.padding_small))
                                        .weight(1f)
                                        .clickable { intent?.send() },
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = MaterialTheme.colorScheme.primary,
                                        textAlign = TextAlign.Center,
                                    ),
                                )
                            }
                        },
                        true,
                    )
                }
            }
        }
        if (viewModel.dialogState != null)
            ManageHistoryDialog(viewModel)
    }
}
