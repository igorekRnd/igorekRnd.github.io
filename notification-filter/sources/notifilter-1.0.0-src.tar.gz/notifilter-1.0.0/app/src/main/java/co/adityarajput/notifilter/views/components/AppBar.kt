package co.adityarajput.notifilter.views.components

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import co.adityarajput.notifilter.R
import co.adityarajput.notifilter.views.Theme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBar(
    title: String,
    canNavigateBack: Boolean,
    leadingIconOnClick: () -> Unit = {},
    actions: @Composable RowScope.() -> Unit = {},
) {
    TopAppBar(
        {
            Text(
                title,
                style = MaterialTheme.typography.headlineMedium.copy(
                    // INFO: The font is monospaced, so a long title needs a smaller size
                    // to fit next to the action buttons instead of being cut off
                    fontSize = when {
                        canNavigateBack -> MaterialTheme.typography.headlineMedium.fontSize
                        title.length > 12 -> MaterialTheme.typography.titleLarge.fontSize
                        else -> MaterialTheme.typography.headlineLarge.fontSize
                    },
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        },
        colors = TopAppBarDefaults.topAppBarColors().copy(
            containerColor = MaterialTheme.colorScheme.primary,
        ),
        // INFO: No navigation icon on the top-level screen: the logo that used to sit here
        // was decorative, was wrapped in a button that did nothing, and its slot is better
        // spent on the title
        navigationIcon = {
            if (canNavigateBack)
                IconButton(leadingIconOnClick) {
                    Icon(
                        painterResource(R.drawable.arrow_back),
                        stringResource(R.string.alttext_back_button),
                    )
                }
        },
        actions = actions,
    )
}

@Preview
@Composable
private fun HomeAppBarPreview() {
    Theme {
        AppBar(stringResource(R.string.app_name), false)
    }
}

@Preview
@Composable
private fun AppBarPreview() {
    Theme {
        AppBar("Page Title", true)
    }
}
